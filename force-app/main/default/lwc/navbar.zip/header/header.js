import { LightningElement, track, api, wire } from 'lwc';
import UnicornBuses from '@salesforce/apex/UnicornBuses.buslist';
import { publish, MessageContext } from 'lightning/messageService';
import dataTransferMessageChannel from '@salesforce/messageChannel/openRecord__c';

export default class Header extends LightningElement {

    @track data = [];
    @api recordId;
    @api cityOne = '';
    @api cityTwo = '';

    @wire(MessageContext)
    messageContext;



    connectedCallback(){
        
        UnicornBuses()
        .then(response => {
            this.data = response;
        })
        .catch(error => {
            window.alert("Error occured :" +error);
        })
    }

    handleChangeCityOne(event){
        this.cityOne = event.target.value;
    }

    handleChangeCityTwo(event){
        this.cityTwo = event.target.value;
    }

    handleSubmit(){
        UnicornBuses({pickUp:this.cityOne , destination:this.cityTwo})
        .then(response => {
            this.data = response;
            if(this.data.length == 0){
                window.alert('No bus available for this route');
            }
        })
        .catch(error => {
            window.alert('Error occurred'+error);
        })
    }


    handleViewSeats(event){
        const valueToBeSent = event.target.value;

        const payLoad = {
            Data: valueToBeSent
        };

        publish(this.messageContext , dataTransferMessageChannel, payLoad)
    }
    
}