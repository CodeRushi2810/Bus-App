import { LightningElement, track, wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import dataTransferMessageChannel from '@salesforce/messageChannel/openRecord__c';
import ReceiveBusData from '@salesforce/apex/fetchSelectedBus.busList';


export default class SelectedBus extends LightningElement {

    subscription = null;

    @wire(MessageContext)
    messageContext;

    @track data = [];

    receivedId;


    connectedCallback(){
        this.subscribeToMessageChannel();
    }

    subscribeToMessageChannel(){
        this.subscription = subscribe(
            this.messageContext,
            dataTransferMessageChannel,
            (message) => this.handleMessage(message)
        );
    }

    handleMessage(message){

        ReceiveBusData({busId:message.Data})
        .then(response => {
            if(response != null){
                this.data = response;
            }
        })
        .catch(error => {
            window.alert("Error Occured : "+error);
        })
    }

}